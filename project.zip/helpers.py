import os
import requests

def lookup(location):

    # Try to lookup the weather for the inputted location
    try:
        api_key = os.environ.get("API_KEY")
        url = f"https://api.weatherapi.com/v1/current.json?key={api_key}&q={location}&days=1&aqi=no&alerts=no"
        response = requests.get(url)
        response.raise_for_status()

    # Return none if it could not be found
    except requests.RequestException:
        return None

    # Try to return the current temperature, feelslike temperature, precipitation, weather condition, and location
    try:
        quote = response.json()
        return {
            "temp": float(quote["current"]["temp_f"]),
            "feelslike": float(quote["current"]["feelslike_f"]),
            "precip": float(quote["current"]["precip_mm"]),
            "condition": quote["current"]["condition"]["text"],
            "city": quote["location"]["name"],
            "state": quote["location"]["region"]
        }

    # Return none if there was an error
    except (KeyError, TypeError, ValueError):
        return None