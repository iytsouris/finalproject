var ypos = 0;
var xpos = 1000;

function setup() {
  var myCanvas = createCanvas(1000, 50);
  // myCanvas.position(0,0);
  myCanvas.parent('canvasDiv');
}

function draw() {
  clear();
  fallingBall();
}

function fallingBall() {

  ypos++

  noStroke()
  fill(50,200,250)

  triangle(xpos-5,ypos,xpos+5,ypos,xpos,ypos-20)
  ellipse(xpos,ypos,10,10);

  ypos = ypos + 1;

  if (ypos > (50)){
  ypos = 0;
  xpos = random(1000);
  }
}