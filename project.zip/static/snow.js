var ypos = 0;
var xpos = 1000;
var xpos2 = 1000;

var snow;

function preload() {
	snow = loadImage("static/snow.png");
    snow.resize(10, 0)
}

function setup() {
  var myCanvas = createCanvas(1000, 75);
  myCanvas.parent('canvasDiv');
}

function draw() {
  clear();
  fallingBall();
}

function fallingBall() {

  ypos++

  noStroke()
  image(snow, xpos, ypos, 25, 25)


  ypos = ypos + 1;

  if (ypos > (65)){
  ypos = 0;
  xpos = random(900);
  }
}
