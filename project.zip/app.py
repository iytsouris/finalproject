import os
from flask import Flask, render_template, request

from helpers import lookup

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


# Home Page
@app.route("/", methods=["GET", "POST"])
def index():
    # If reached via POST (through someone entering their location)
    if request.method == "POST":
        data=lookup(request.form.get('location'))

        # If location is invalid
        if data is None:
            return render_template("apology.html", isIndex=True)

        # Default temp to Fahrenheit
        temp = "F"

        # If user selected Celsius
        if request.form.get('measurement') == "celsius":

            # Set temperature to Celsius
            temp = "C"

        # Default precipitation 0 -> no rain or snow
        precip = 0


        # If there is precipitation
        if data["precip"] > 0:

            # If it's below freezing
            if data["feelslike"] < 32:

                #Precipitation is 2 -> snow
                precip = 2

            # If it's above freezing
            else:
                # Precipitation is 1 -> rain
                precip = 1

        # Load the respective page depending on the temperature
        if data["feelslike"] < 0:
            return render_template("<0.html", data=data)
        elif data["feelslike"] > 0 and data["feelslike"] < 26:
            return render_template("0-25.html", data=data, precip=precip, temp=temp)
        elif data["feelslike"] > 25 and data["feelslike"] < 40:
            return render_template("26-40.html", data=data, precip=precip, temp=temp)
        elif data["feelslike"] > 39 and data["feelslike"] < 55:
            return render_template("41-55.html", data=data, precip=precip, temp=temp)
        elif data["feelslike"] > 54 and data["feelslike"] < 70:
            return render_template("56-70.html", data=data, precip=precip, temp=temp)
        elif data["feelslike"] > 69 and data["feelslike"] < 85:
            return render_template("71-85.html", data=data, precip=precip, temp=temp)
        elif data["feelslike"] > 84 and data["feelslike"] < 100:
            return render_template("86-100.html", data=data, precip=precip, temp=temp)
        else:
            return render_template(">101.html", data=data, precip=precip, temp=temp)

    # If page reached via GET (by landing on the homepage)
    else:
        return render_template("index.html", isIndex=True)

